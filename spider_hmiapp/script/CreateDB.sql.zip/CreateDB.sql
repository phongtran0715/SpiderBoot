CREATE DATABASE  IF NOT EXISTS `spiderboot` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `spiderboot`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: spiderboot
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `download_cluster`
--

DROP TABLE IF EXISTS `download_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `download_cluster` (
  `ClusterId` int(11) NOT NULL AUTO_INCREMENT,
  `IpAddress` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Port` int(11) NOT NULL,
  `ClusterName` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ClusterId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `download_cluster`
--

LOCK TABLES `download_cluster` WRITE;
/*!40000 ALTER TABLE `download_cluster` DISABLE KEYS */;
/*!40000 ALTER TABLE `download_cluster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `google_account`
--

DROP TABLE IF EXISTS `google_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `google_account` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Api` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `ClientId` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ClientSecret` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `AccountType` int(11) DEFAULT NULL,
  `AppName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `google_account`
--

LOCK TABLES `google_account` WRITE;
/*!40000 ALTER TABLE `google_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `google_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_channel_list`
--

DROP TABLE IF EXISTS `home_channel_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_channel_list` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ChannelId` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ChannelName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GoogleAccount` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VideoIntro` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VideoOutro` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Logo` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DescriptionTemplate` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TitleTemplate` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_channel_list`
--

LOCK TABLES `home_channel_list` WRITE;
/*!40000 ALTER TABLE `home_channel_list` DISABLE KEYS */;
INSERT INTO `home_channel_list` VALUES (1,'UCgGttbDvptiImN1GJkmPdWA','Top Hay La','phongtran0715@gmail.com','video intro 1','video outro 1','logo 1','description 1','title 1');
/*!40000 ALTER TABLE `home_channel_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_monitor_channel_mapping`
--

DROP TABLE IF EXISTS `home_monitor_channel_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_monitor_channel_mapping` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `HomeChannelId` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MonitorChannelId` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TimeIntervalSync` int(11) DEFAULT '100',
  `StatusSync` int(11) DEFAULT '0',
  `Action` int(11) DEFAULT '0',
  `LastSyncTime` datetime DEFAULT NULL,
  `DownloadClusterId` int(11) DEFAULT NULL,
  `ProcessClusterId` int(11) DEFAULT NULL,
  `UploadClusterId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_monitor_channel_mapping`
--

LOCK TABLES `home_monitor_channel_mapping` WRITE;
/*!40000 ALTER TABLE `home_monitor_channel_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `home_monitor_channel_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitor_channel_list`
--

DROP TABLE IF EXISTS `monitor_channel_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_channel_list` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ChannelId` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ChannelName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitor_channel_list`
--

LOCK TABLES `monitor_channel_list` WRITE;
/*!40000 ALTER TABLE `monitor_channel_list` DISABLE KEYS */;
INSERT INTO `monitor_channel_list` VALUES (1,'UCCylCCM6AhnK-BmalWuVBJg','DLP movie edit'),(2,'UC-ApbP8o-FFhNnEFad8JNAw','DLP Weird');
/*!40000 ALTER TABLE `monitor_channel_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_cluster`
--

DROP TABLE IF EXISTS `process_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_cluster` (
  `ClusterId` int(11) NOT NULL,
  `IpAddress` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Port` int(11) NOT NULL,
  `ClusterName` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ClusterId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_cluster`
--

LOCK TABLES `process_cluster` WRITE;
/*!40000 ALTER TABLE `process_cluster` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_cluster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spider_account`
--

DROP TABLE IF EXISTS `spider_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spider_account` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spider_account`
--

LOCK TABLES `spider_account` WRITE;
/*!40000 ALTER TABLE `spider_account` DISABLE KEYS */;
INSERT INTO `spider_account` VALUES (1,'sys','admin',NULL),(2,'phong','','phongtran0715@gmail.com');
/*!40000 ALTER TABLE `spider_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `upload_cluster`
--

DROP TABLE IF EXISTS `upload_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `upload_cluster` (
  `ClusterId` int(11) NOT NULL,
  `IpAddress` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Port` int(11) NOT NULL,
  `ClusterName` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ClusterId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `upload_cluster`
--

LOCK TABLES `upload_cluster` WRITE;
/*!40000 ALTER TABLE `upload_cluster` DISABLE KEYS */;
/*!40000 ALTER TABLE `upload_cluster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_container`
--

DROP TABLE IF EXISTS `video_container`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_container` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VideoId` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `Title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Tag` blob,
  `Description` blob,
  `Thumbnail` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VideoLocation` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ChannelMappingId` int(11) NOT NULL,
  `DownloadDate` datetime DEFAULT NULL,
  `ProcessStatus` int(11) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_container`
--

LOCK TABLES `video_container` WRITE;
/*!40000 ALTER TABLE `video_container` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_container` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-07 12:00:14
